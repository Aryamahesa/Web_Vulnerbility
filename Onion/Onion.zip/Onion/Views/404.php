<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404</title>
    <link rel="stylesheet" href="/css/404.css">
</head>
<body>
    <div class="not-found">
        <h1>404</h1>
        <p>Halaman yang Anda cari tidak ditemukan.</p>
        <button onclick="window.location.href='/'">Kembali ke Beranda</button>
    </div>
</body>
</html>